#ifndef _TIMING_INCLUDE
#define _TIMING_INCLUDE


long getTimeMilliseconds();


#endif // _TIMING_INCLUDE


