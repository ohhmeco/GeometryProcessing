#ifndef _PARAMETERIZER_INCLUDE
#define _PARAMETERIZER_INCLUDE


#include "TriangleMesh.h"


class Parameterizer
{
public:
	void harmonicCoordinates(TriangleMesh *mesh);

private:
	
};


#endif // _PARAMETERIZER_INCLUDE

